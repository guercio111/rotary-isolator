# Rotary Isolator — prototype 0.1

Android/Kotlin prototype with three classic rotary controls (LOW/MID/HIGH) and an attempt to attach Android's `Equalizer` to output mix audio session `0`.

## Important limitations
- Android/OEM audio policy may reject global output effects; the app reports this rather than pretending it works.
- This first prototype uses the platform graphic Equalizer. It is **not** a true three-way crossover isolator and the minimum attenuation is limited by the device effect (often around -15 dB), not guaranteed silence.
- It is a source project, not a compiled APK. Build with Android Studio / Android SDK and Gradle 8.9+ using Android Gradle Plugin 8.7.3.
