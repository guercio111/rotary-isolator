package com.example.rotaryisolator

import android.app.Activity
import android.app.AlertDialog
import android.media.audiofx.Equalizer
import android.os.Bundle
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import kotlin.math.*

/**
 * Rotary Isolator V2.
 * Uses Android Equalizer session 0 where the device/OEM permits global output effects.
 * HPF/LPF/MID PASS are graphic-EQ approximations, not true crossover filters.
 */
class MainActivity : Activity() {
    private var eq: Equalizer? = null
    private var effectEnabled = false
    private var eqEnabled = true
    private var filtersEnabled = false
    private var minMb = -1500
    private var maxMb = 1500
    private var boostDb = 9
    private var useSliders = false
    private lateinit var status: TextView
    private lateinit var eqControls: LinearLayout
    private lateinit var filterControls: LinearLayout
    private val eqValues = floatArrayOf(0f, 0f, 0f) // -1..+1, center = 0 dB
    private val filterValues = floatArrayOf(0f, 0f, 0f) // HPF, MID PASS, LPF; zero = off
    private val eqRanges = arrayOf(0f..250f, 250f..4000f, 4000f..24000f)
    private val gold = Color.rgb(214, 179, 106)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        val prefs = getSharedPreferences("rotary_v2", MODE_PRIVATE)
        boostDb = prefs.getInt("boost_db", 9).coerceIn(3, 12)
        useSliders = prefs.getBoolean("sliders", false)
        for (i in 0..2) {
            eqValues[i] = prefs.getFloat("eq_$i", 0f).coerceIn(-1f, 1f)
            filterValues[i] = prefs.getFloat("filter_$i", 0f).coerceIn(0f, 1f)
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 10, 22, 10)
            setBackgroundColor(Color.rgb(17, 19, 23))
        }
        val title = TextView(this).apply {
            text = "ROTARY ISOLATOR  V2"
            textSize = 22f; letterSpacing = .18f; setTextColor(Color.WHITE)
            gravity = Gravity.CENTER; typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        root.addView(title, LinearLayout.LayoutParams(-1, 38))
        val subtitle = TextView(this).apply {
            text = "3-BAND MASTER EQ  •  V10 / XONE STYLE"
            textSize = 10f; letterSpacing = .14f; setTextColor(Color.LTGRAY); gravity = Gravity.CENTER
        }
        root.addView(subtitle, LinearLayout.LayoutParams(-1, 22))

        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(sectionLabel("EQUALIZER  •  CENTER = 0 dB"))
        eqControls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; weightSum = 3f }
        content.addView(eqControls, LinearLayout.LayoutParams(-1, dp(220)))
        buildEqControls()

        content.addView(sectionLabel("FILTERS  •  GRAPHIC EQ APPROXIMATION"))
        filterControls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; weightSum = 3f }
        content.addView(filterControls, LinearLayout.LayoutParams(-1, dp(110)))
        buildFilterControls()
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, 5, 0, 0) }
        val eqButton = Button(this).apply { text = "EQ ON"; setOnClickListener { eqEnabled = !eqEnabled; text = if (eqEnabled) "EQ ON" else "EQ BYPASS"; applyAll() } }
        val filterButton = Button(this).apply { text = "FILTERS OFF"; setOnClickListener { filtersEnabled = !filtersEnabled; text = if (filtersEnabled) "FILTERS ON" else "FILTERS OFF"; applyAll() } }
        val settingsButton = Button(this).apply { text = "OPTIONS"; setOnClickListener { showSettings() } }
        buttons.addView(eqButton, LinearLayout.LayoutParams(0, 48, 1f))
        buttons.addView(filterButton, LinearLayout.LayoutParams(0, 48, 1f))
        buttons.addView(settingsButton, LinearLayout.LayoutParams(0, 48, 1f))
        root.addView(buttons, LinearLayout.LayoutParams(-1, 52))
        status = TextView(this).apply { text = "Connecting audio effect…"; textSize = 11f; setTextColor(0xFFB9BEC7.toInt()); gravity = Gravity.CENTER }
        root.addView(status, LinearLayout.LayoutParams(-1, 22))
        setContentView(root)
        connectEffect()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).roundToInt()

    private fun sectionLabel(text: String) = TextView(this).apply {
        this.text = text; textSize = 10f; letterSpacing = .12f; setTextColor(gold); gravity = Gravity.CENTER
        setPadding(0, 4, 0, 2)
    }

    private fun buildEqControls() {
        eqControls.removeAllViews()
        listOf("LOW", "MID", "HIGH").forEachIndexed { i, name ->
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
            if (useSliders) {
                val label = TextView(this).apply { text = "$name  ${formatDb(eqValues[i])}"; setTextColor(Color.WHITE); gravity = Gravity.CENTER; textSize = 14f }
                val seek = SeekBar(this).apply {
                    max = 200; progress = ((eqValues[i] + 1f) * 100f).roundToInt()
                    setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                        override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) { if (user) { eqValues[i] = p / 100f - 1f; label.text = "$name  ${formatDb(eqValues[i])}"; applyAll() } }
                        override fun onStartTrackingTouch(s: SeekBar?) {}
                        override fun onStopTrackingTouch(s: SeekBar?) {}
                    })
                }
                col.addView(label); col.addView(seek, LinearLayout.LayoutParams(-1, 55))
            } else {
                val knob = KnobView(this, name, eqValues[i], true, { v -> eqValues[i] = v; applyAll() }) { formatDb(eqValues[i]) }
                col.addView(knob, LinearLayout.LayoutParams(-1, 0, 1f))
            }
            eqControls.addView(col, LinearLayout.LayoutParams(0, -1, 1f))
        }
    }

    private fun buildFilterControls() {
        filterControls.removeAllViews()
        listOf("HPF", "MID PASS", "LPF").forEachIndexed { i, name ->
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
            val label = TextView(this).apply { text = "$name  ${filterValues[i].times(100).roundToInt()}%"; setTextColor(Color.WHITE); gravity = Gravity.CENTER; textSize = 12f }
            val seek = SeekBar(this).apply {
                max = 100; progress = (filterValues[i] * 100f).roundToInt()
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) { if (user) { filterValues[i] = p / 100f; label.text = "$name  $p%"; applyAll() } }
                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) {}
                })
            }
            col.addView(label); col.addView(seek, LinearLayout.LayoutParams(-1, 52))
            filterControls.addView(col, LinearLayout.LayoutParams(0, -1, 1f))
        }
    }

    private fun connectEffect() {
        try {
            eq = Equalizer(0, 0).also { e ->
                e.enabled = false
                minMb = e.bandLevelRange[0].toInt(); maxMb = e.bandLevelRange[1].toInt()
            }
            status.text = "Output effect detected • ${eq?.numberOfBands} bands • ${minMb / 100f} / ${maxMb / 100f} dB"
        } catch (_: Throwable) {
            status.text = "Global output effect unavailable on this device"
        }
        applyAll()
    }

    private fun formatDb(v: Float): String {
        val db = v * boostDb
        return if (db > 0.04f) "+${"%.1f".format(db)} dB" else if (db < -0.04f) "${"%.1f".format(db)} dB" else "0.0 dB"
    }

    private fun applyAll() {
        val prefs = getSharedPreferences("rotary_v2", MODE_PRIVATE).edit()
        for (i in 0..2) { prefs.putFloat("eq_$i", eqValues[i]); prefs.putFloat("filter_$i", filterValues[i]) }
        prefs.apply()
        val e = eq ?: return
        try {
            val maxBoostMb = boostDb * 100
            val lowPassStrength = if (filtersEnabled) filterValues[2] else 0f
            val highPassStrength = if (filtersEnabled) filterValues[0] else 0f
            val midPassStrength = if (filtersEnabled) filterValues[1] else 0f
            for (b in 0 until e.numberOfBands.toInt()) {
                val hz = e.getCenterFreq(b.toShort()) / 1000f
                var gainMb = 0f
                if (eqEnabled) {
                    val band = eqRanges.indexOfFirst { hz >= it.start && hz < it.endInclusive }.let { if (it < 0) 2 else it }
                    gainMb = eqValues[band] * maxBoostMb
                }
                var cutMb = 0f
                if (highPassStrength > 0f) {
                    val cutoff = 30f * (6000f / 30f).pow(highPassStrength)
                    if (hz < cutoff) cutMb -= (minMb.absoluteValue * highPassStrength * (1f - hz / cutoff)).roundToInt()
                }
                if (lowPassStrength > 0f) {
                    val cutoff = 18000f * (250f / 18000f).pow(lowPassStrength)
                    if (hz > cutoff) cutMb -= (minMb.absoluteValue * lowPassStrength * (1f - cutoff / hz)).roundToInt()
                }
                if (midPassStrength > 0f && (hz < 250f || hz > 4000f)) {
                    cutMb -= (minMb.absoluteValue * midPassStrength * 0.85f).roundToInt()
                }
                val total = (gainMb + cutMb).roundToInt().coerceIn(minMb, maxMb).toShort()
                e.setBandLevel(b.toShort(), total)
            }
            val shouldEnable = eqEnabled || filtersEnabled
            e.enabled = shouldEnable
            effectEnabled = shouldEnable
            status.text = if (shouldEnable) "Output processing ON • EQ ${if (eqEnabled) "ON" else "BYPASS"} • filters ${if (filtersEnabled) "ON" else "OFF"}" else "BYPASS • output processing OFF"
        } catch (_: Throwable) { status.text = "Android blocked global audio processing" }
    }

    private fun showSettings() {
        val choices = arrayOf("Boost massimo: +3 dB", "Boost massimo: +6 dB", "Boost massimo: +9 dB", "Boost massimo: +12 dB", "Controlli a manopola", "Controlli a slider")
        val selected = when (boostDb) { 3 -> 0; 6 -> 1; 9 -> 2; else -> 3 }
        AlertDialog.Builder(this).setTitle("ROTARY ISOLATOR • OPTIONS")
            .setSingleChoiceItems(choices, -1) { dialog, which ->
                when (which) {
                    in 0..3 -> boostDb = listOf(3, 6, 9, 12)[which]
                    4 -> useSliders = false
                    5 -> useSliders = true
                }
                getSharedPreferences("rotary_v2", MODE_PRIVATE).edit().putInt("boost_db", boostDb).putBoolean("sliders", useSliders).apply()
                buildEqControls(); applyAll(); dialog.dismiss()
            }
            .setNegativeButton("CHIUDI", null).show()
    }

    override fun onDestroy() {
        try { eq?.enabled = false; eq?.release() } catch (_: Throwable) {}
        super.onDestroy()
    }
}

/** Large hit target; vertical drag is intentionally easier than circular rotation.
 * Mouse wheel changes the value in small steps. */
private class KnobView(
    context: android.content.Context,
    private val label: String,
    initial: Float,
    private val bipolar: Boolean,
    private val onValue: (Float) -> Unit,
    private val valueText: () -> String
) : View(context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var value = initial
    private var downY = 0f
    private var downValue = initial
    private val gold = Color.rgb(214, 179, 106)
    init { isFocusable = true; contentDescription = "$label control. Drag up or down to adjust." }
    private fun knobRect(): RectF { val s = min(width, height) * .72f; return RectF(width/2f-s/2, height/2f-s/2-5, width/2f+s/2, height/2f+s/2-5) }
    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val r = knobRect(); val cx = r.centerX(); val cy = r.centerY(); val rad = r.width()/2
        p.style = Paint.Style.STROKE; p.strokeWidth = 8f; p.strokeCap = Paint.Cap.ROUND
        p.color = 0xFF454B55.toInt(); c.drawArc(RectF(cx-rad+5, cy-rad+5, cx+rad-5, cy+rad-5), 135f, 270f, false, p)
        p.color = gold
        val sweep = if (bipolar) 135f + 135f * value else 270f * value
        val start = if (bipolar) 270f else 135f
        val extent = if (bipolar) abs(135f * value) else sweep
        c.drawArc(RectF(cx-rad+5, cy-rad+5, cx+rad-5, cy+rad-5), if (bipolar && value < 0) 135f + sweep else start, extent, false, p)
        p.style = Paint.Style.FILL; p.color = 0xFF292E36.toInt(); c.drawCircle(cx, cy, rad*.78f, p)
        p.color = 0xFF59616D.toInt(); p.style = Paint.Style.STROKE; p.strokeWidth = 2f; c.drawCircle(cx, cy, rad*.78f, p)
        val norm = if (bipolar) (value + 1f) / 2f else value
        val a = Math.toRadians((135 + 270 * norm).toDouble())
        val x = cx + cos(a).toFloat() * rad*.58f; val y = cy + sin(a).toFloat() * rad*.58f
        p.color = Color.WHITE; p.strokeWidth = 4f; c.drawLine(cx, cy, x, y, p)
        p.style = Paint.Style.FILL; p.color = Color.WHITE; p.textAlign = Paint.Align.CENTER; p.textSize = 18f; p.typeface = android.graphics.Typeface.DEFAULT_BOLD
        c.drawText(label, cx, r.bottom+27, p)
        p.color = gold; p.textSize = 13f; p.typeface = android.graphics.Typeface.DEFAULT
        c.drawText(valueText(), cx, r.bottom+47, p)
        p.color = 0xFF9DA5B1.toInt(); p.textSize = 10f
        if (bipolar) { c.drawText("CUT", cx-rad*.68f, r.centerY()+rad*.95f, p); c.drawText("BOOST", cx+rad*.68f, r.centerY()+rad*.95f, p) }
        else { c.drawText("-", cx-rad*.68f, r.centerY()+rad*.95f, p); c.drawText("+", cx+rad*.68f, r.centerY()+rad*.95f, p) }
    }
    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> { downY = event.y; downValue = value; parent?.requestDisallowInterceptTouchEvent(true); return true }
            MotionEvent.ACTION_MOVE -> { value = (downValue - (event.y - downY) / 190f).coerceIn(if (bipolar) -1f else 0f, 1f); onValue(value); invalidate(); return true }
            MotionEvent.ACTION_UP -> { performClick(); return true }
            MotionEvent.ACTION_CANCEL -> return true
        }
        return true
    }
    override fun onGenericMotionEvent(event: MotionEvent): Boolean {
        if (event.action == MotionEvent.ACTION_SCROLL) {
            val delta = event.getAxisValue(MotionEvent.AXIS_VSCROLL)
            value = (value + delta * if (bipolar) 0.025f else 0.02f).coerceIn(if (bipolar) -1f else 0f, 1f)
            onValue(value); invalidate(); return true
        }
        return super.onGenericMotionEvent(event)
    }
    override fun performClick(): Boolean { super.performClick(); return true }
}
