package com.example.rotaryisolator

import android.app.Activity
import android.media.audiofx.Equalizer
import android.os.Bundle
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.*

/** Prototype: uses Android's global output-mix Equalizer session (session 0) where the device permits it.
 * Android/OEM policy may reject global effects. The platform Equalizer is a graphic EQ, not a true crossover isolator.
 */
class MainActivity : Activity() {
    private var eq: Equalizer? = null
    private var enabled = false
    private lateinit var status: TextView
    private val controls = mutableListOf<KnobView>()
    private var minMb = -1500
    private var maxMb = 0
    private var bands = 0
    private val ranges = arrayOf(0f..250f, 250f..4000f, 4000f..24000f)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(28, 18, 28, 16); setBackgroundColor(Color.rgb(17,19,23)) }
        val title = TextView(this).apply { text = "ROTARY ISOLATOR"; textSize = 24f; letterSpacing = .18f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; typeface = android.graphics.Typeface.DEFAULT_BOLD }
        root.addView(title, LinearLayout.LayoutParams(-1, 48))
        val subtitle = TextView(this).apply { text = "3-BAND MASTER  •  LOW / MID / HIGH"; textSize = 11f; letterSpacing = .16f; setTextColor(Color.LTGRAY); gravity = Gravity.CENTER }
        root.addView(subtitle, LinearLayout.LayoutParams(-1, 26))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; weightSum = 3f }
        listOf("LOW", "MID", "HIGH").forEachIndexed { i, label ->
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; weightSum = 1f }
            val knob = KnobView(this, label) { value -> applyBand(i, value) }
            controls.add(knob)
            col.addView(knob, LinearLayout.LayoutParams(-1, 0, 1f))
            row.addView(col, LinearLayout.LayoutParams(0, -1, 1f))
        }
        root.addView(row, LinearLayout.LayoutParams(-1, 0, 1f))
        val bottom = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, 6, 0, 0) }
        val bypass = Button(this).apply { text = "BYPASS / ON"; setOnClickListener { toggle() } }
        bottom.addView(bypass)
        status = TextView(this).apply { text = "Audio effect not connected"; textSize = 12f; setTextColor(0xFFB9BEC7.toInt()); gravity = Gravity.CENTER; setPadding(18,0,0,0) }
        bottom.addView(status, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(bottom, LinearLayout.LayoutParams(-1, 54))
        setContentView(root)
        connectEffect()
    }

    private fun connectEffect() {
        try {
            eq = Equalizer(0, 0).also { e ->
                e.enabled = false
                bands = e.numberOfBands.toInt()
                minMb = e.bandLevelRange[0].toInt(); maxMb = e.bandLevelRange[1].toInt()
            }
            enabled = false
            status.text = "Output effect detected • ${bands} bands • ${minMb / 100f} dB min"
        } catch (t: Throwable) {
            status.text = "Global effect not available on this device"
        }
    }

    private fun applyBand(index: Int, amount: Float) {
        val e = eq ?: return
        try {
            val target = (minMb * (1f - amount)).roundToInt().coerceIn(minMb, maxMb).toShort()
            for (b in 0 until e.numberOfBands.toInt()) {
                val hz = e.getCenterFreq(b.toShort()) / 1000f
                val range = ranges[index]
                if (hz >= range.start && hz < range.endInclusive) e.setBandLevel(b.toShort(), target)
            }
            if (!e.enabled) e.enabled = true
            enabled = true
            status.text = "Output EQ active • ${"%.0f".format(amount * 100)}% ${listOf("LOW","MID","HIGH")[index]}"
        } catch (_: Throwable) { status.text = "Android blocked global audio processing" }
    }

    private fun toggle() {
        try {
            enabled = !enabled
            eq?.enabled = enabled
            status.text = if (enabled) "Output effect ON" else "BYPASS • output effect OFF"
        } catch (_: Throwable) { status.text = "Effect unavailable" }
    }

    override fun onDestroy() { try { eq?.release() } catch (_: Throwable) {}; super.onDestroy() }
}

private class KnobView(context: android.content.Context, private val label: String, private val onValue: (Float) -> Unit) : View(context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var value = 1f
    private var downAngle = 0f
    private var downValue = 1f
    private val gold = Color.rgb(214,179,106)
    private fun knobRect(): RectF { val s = min(width, height) * .68f; return RectF(width/2f-s/2, height/2f-s/2-8, width/2f+s/2, height/2f+s/2-8) }
    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val r = knobRect(); val cx=r.centerX(); val cy=r.centerY(); val rad=r.width()/2
        p.style=Paint.Style.STROKE; p.strokeWidth=7f; p.strokeCap=Paint.Cap.ROUND; p.color=0xFF454B55.toInt(); c.drawArc(RectF(cx-rad+5,cy-rad+5,cx+rad-5,cy+rad-5),135f,270f,false,p)
        p.color=gold; c.drawArc(RectF(cx-rad+5,cy-rad+5,cx+rad-5,cy+rad-5),135f,270f*value,false,p)
        p.style=Paint.Style.FILL; p.color=0xFF292E36.toInt(); c.drawCircle(cx,cy,rad*.78f,p)
        p.color=0xFF59616D.toInt(); p.style=Paint.Style.STROKE; p.strokeWidth=2f; c.drawCircle(cx,cy,rad*.78f,p)
        val a=Math.toRadians((135+270*value).toDouble()); val x=cx+cos(a).toFloat()*rad*.58f; val y=cy+sin(a).toFloat()*rad*.58f
        p.color=Color.WHITE; p.strokeWidth=4f; c.drawLine(cx,cy,x,y,p)
        p.style=Paint.Style.FILL; p.color=Color.WHITE; p.textAlign=Paint.Align.CENTER; p.textSize=20f; p.typeface=android.graphics.Typeface.DEFAULT_BOLD; c.drawText(label,cx, r.bottom+34,p)
        p.color=gold; p.textSize=14f; p.typeface=android.graphics.Typeface.DEFAULT; c.drawText("${(value*100).roundToInt()}%",cx,r.bottom+57,p)
        p.color=0xFF9DA5B1.toInt(); p.textSize=10f; c.drawText("CUT",cx-rad*.68f,r.centerY()+rad*.95f,p); c.drawText("OPEN",cx+rad*.68f,r.centerY()+rad*.95f,p)
    }
    override fun onTouchEvent(event: MotionEvent): Boolean {
        val r=knobRect(); val cx=r.centerX(); val cy=r.centerY()
        when(event.action) {
            MotionEvent.ACTION_DOWN -> { downAngle=atan2(event.y-cy,event.x-cx); downValue=value; parent.requestDisallowInterceptTouchEvent(true); return true }
            MotionEvent.ACTION_MOVE -> { val a=atan2(event.y-cy,event.x-cx); var d=Math.toDegrees((a-downAngle).toDouble()).toFloat(); if(d>180)d-=360f; if(d< -180)d+=360f; value=(downValue+d/270f).coerceIn(0f,1f); onValue(value); invalidate(); return true }
            MotionEvent.ACTION_UP -> { performClick(); return true }
        }; return true
    }
    override fun performClick(): Boolean { super.performClick(); return true }
}
