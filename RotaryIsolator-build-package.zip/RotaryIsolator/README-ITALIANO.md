# ROTARY ISOLATOR — prototipo Android

Questo progetto contiene una prima interfaccia Android con tre manopole rotative classiche LOW / MID / HIGH.

## Limiti tecnici da conoscere

- Il progetto **non è ancora un isolator DJ professionale**: usa l'effetto grafico `Equalizer` fornito da Android.
- L'attenuazione massima dipende dall'effetto audio del dispositivo e potrebbe non arrivare al silenzio assoluto.
- L'effetto sull'audio di tutte le app dipende dal firmware Samsung e dalle restrizioni Android. La creazione dell'oggetto con sessione audio `0` non garantisce che Android consenta l'elaborazione globale.
- Non è stato possibile verificare il funzionamento sul Galaxy Tab A11+ in questo ambiente.

## Ottenere l'APK usando soltanto il tablet

Il progetto include una GitHub Action che compila automaticamente l'APK in cloud. Serve un account GitHub gratuito e una connessione Internet.

1. Estrarre lo ZIP sul tablet.
2. Creare un nuovo repository su https://github.com/new.
3. Caricare nel repository **il contenuto della cartella `RotaryIsolator`**, mantenendo le cartelle (`app`, `.github/workflows`, ecc.). Non caricare soltanto lo ZIP.
4. Aprire la scheda **Actions** del repository. Se GitHub chiede di abilitare le Actions, abilitarle.
5. La compilazione parte al primo `push`; in alternativa aprire **Build Rotary Isolator APK** e premere **Run workflow**.
6. Quando termina con il segno verde, aprire la compilazione e scaricare l'artifact `rotary-isolator-debug-apk`.
7. Estrarre l'artifact: contiene `app-debug.apk`. Aprirlo sul tablet e autorizzare l'installazione da quella sorgente, se Android lo richiede.

Il file prodotto è una build **debug** firmata automaticamente per i test. Non è una versione pubblicata sul Play Store.

## Requisiti di compilazione

- JDK 17
- Gradle 8.9
- Android SDK Platform 35 e Build Tools 35.0.0

La workflow GitHub installa questi strumenti automaticamente.
