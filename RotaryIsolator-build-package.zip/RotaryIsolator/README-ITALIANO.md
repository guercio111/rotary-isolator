# ROTARY ISOLATOR V2 — pacchetto Android

Questa versione mantiene l'effetto audio globale tramite `Equalizer(0, 0)`, che sul tablet dell'utente era già risultato funzionante, e aggiunge:

- EQ LOW / MID / HIGH con centro a **0 dB**, taglio a sinistra e boost a destra.
- Boost selezionabile: +3 / +6 / +9 / +12 dB (il limite reale resta quello esposto dal dispositivo Android).
- Manopole più grandi, regolabili trascinando verso l'alto o verso il basso; la rotellina del mouse modifica il valore a piccoli passi.
- Possibilità di scegliere manopole oppure slider per l'EQ.
- HPF, MID PASS e LPF indipendenti, con intensità regolabile.
- Bypass separato per EQ e filtri.
- Salvataggio automatico delle impostazioni e dei valori.

## Nota tecnica importante

L'API pubblica Android `Equalizer` è un equalizzatore grafico a bande. Non offre veri filtri analogici/crossover come quelli di un Xone 92 o DJM-V10. Perciò HPF, MID PASS e LPF in questa versione sono **approssimazioni grafiche**: il risultato dipende dal numero e dalle frequenze delle bande messe a disposizione dal firmware Samsung. L'EQ LOW/MID/HIGH invece usa guadagni positivi e negativi reali entro il range dichiarato dal dispositivo.

L'elaborazione globale usa la sessione audio 0, come la versione precedente. Android/Samsung può limitarla in base al firmware o all'app in riproduzione. Non è stato possibile compilare o provare questa V2 sul tablet da questo ambiente: la GitHub Action del repository eseguirà la compilazione.

## Come ottenere l'APK nel repository GitHub già utilizzato

1. Scarica il file `RotaryIsolator-build-package.zip` fornito in questa conversazione.
2. Apri il repository GitHub che hai già creato (`guercio111/rotary-isolator`).
3. Apri il file ZIP già presente nel repository, `RotaryIsolator-build-package.zip`, e scegli **Replace file** se GitHub lo propone; altrimenti elimina il vecchio ZIP e carica quello nuovo con lo stesso nome.
4. Conferma con **Commit changes**. Non modificare il file workflow `build-apk.yml` che hai già sistemato.
5. Apri **Actions**: partirà la compilazione automatica. Attendi il segno verde.
6. Apri l'esecuzione completata e scarica l'artifact `rotary-isolator-debug-apk`.
7. Estrai l'artifact e installa `app-debug.apk` sul tablet. Se Android lo chiede, autorizza l'installazione da quella sorgente.

Se la compilazione fallisce, mandami uno screenshot della schermata rossa di GitHub Actions: non cambiare altri file prima di aver visto l'errore.
